@extends('admin.layouts.app') {{-- sesuaikan dengan layout admin kamu --}}

@section('content')
<div class="container">
    <h1>{{ $potential->title }}</h1>
    <img src="{{ asset('storage/' . $potential->image) }}" alt="{{ $potential->title }}" style="max-width: 400px; display:block; margin-bottom:20px;">
    <div>
        {!! nl2br(e($potential->content)) !!}
    </div>
    <a href="{{ route('admin.potential.index') }}" class="btn btn-secondary mt-3">Kembali</a>
</div>
@endsection
